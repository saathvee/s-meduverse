import React from 'react';
import { Video, Users, Clock, Award, BookOpen, HeadphonesIcon } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Users,
      title: 'Expert Faculty',
      description: 'Learn from faculty with academic and field experience who understand both theory and practical applications.',
      color: 'text-blue-600'
    },
    {
      icon: BookOpen,
      title: 'Structured Study Plans',
      description: 'Follow organized timetables and structured curriculum aligned with latest syllabus and exam trends.',
      color: 'text-green-600'
    },
    {
      icon: Video,
      title: 'Bilingual Teaching',
      description: 'Learn in English & Tamil for regional accessibility, making complex concepts easier to understand.',
      color: 'text-purple-600'
    },
    {
      icon: Award,
      title: 'Result-Oriented Approach',
      description: 'Focus on concept clarity with real-life examples, simplified teaching, and updated curriculum.',
      color: 'text-orange-600'
    },
    {
      icon: Clock,
      title: 'Daily Practice & Tests',
      description: 'Regular practice questions, weekly tests, current affairs capsules, and interactive doubt-clearing sessions.',
      color: 'text-red-600'
    },
    {
      icon: HeadphonesIcon,
      title: 'Personalized Guidance',
      description: 'Individual attention, mentoring, feedback, and motivation sessions for every student at every stage.',
      color: 'text-indigo-600'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            🌟 Our Mission & Why Choose S&M EDUVERSE?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            To provide structured and result-oriented coaching with concept-based understanding, individual attention, and bridging the gap between aspiration and achievement through disciplined preparation.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 group">
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gray-50 group-hover:bg-gray-100 transition-colors duration-300 mb-6`}>
                <feature.icon className={`h-6 w-6 ${feature.color}`} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;