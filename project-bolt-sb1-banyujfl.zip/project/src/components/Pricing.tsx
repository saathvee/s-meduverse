import React from 'react';
import { Check, ArrowRight } from 'lucide-react';

const Pricing = () => {
  const plans = [
    {
      name: 'Basic',
      price: '₹4,999',
      period: '/month',
      description: 'Perfect for getting started with your exam preparation',
      features: [
        'Access to recorded lectures',
        'Basic study materials',
        'Monthly mock tests',
        'Email support',
        'Mobile app access'
      ],
      popular: false
    },
    {
      name: 'Premium',
      price: '₹9,999',
      period: '/month',
      description: 'Most popular plan with comprehensive features',
      features: [
        'All Basic features',
        'Live interactive classes',
        'Weekly mock tests',
        'Doubt clearing sessions',
        'Performance analytics',
        'Priority support',
        'Downloadable content'
      ],
      popular: true
    },
    {
      name: 'Elite',
      price: '₹14,999',
      period: '/month',
      description: 'Complete preparation with personal mentoring',
      features: [
        'All Premium features',
        'Personal mentor assigned',
        'Daily mock tests',
        'One-on-one doubt sessions',
        'Custom study plans',
        'Interview preparation',
        'Career guidance',
        '24/7 support'
      ],
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Choose Your Success Plan
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Select the plan that best fits your preparation needs and budget
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div key={index} className={`bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden ${plan.popular ? 'ring-2 ring-blue-600 relative' : ''}`}>
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-blue-600 text-white text-center py-2 text-sm font-medium">
                  Most Popular
                </div>
              )}
              
              <div className={`p-8 ${plan.popular ? 'pt-12' : ''}`}>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                
                <div className="flex items-baseline mb-6">
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  <span className="text-gray-600 ml-1">{plan.period}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center space-x-3">
                      <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2 ${
                  plan.popular 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                }`}>
                  <span>Choose {plan.name}</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Need a custom plan? We've got you covered.</p>
          <button className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors duration-300">
            Contact for Custom Pricing
          </button>
        </div>
      </div>
    </section>
  );
};

export default Pricing;