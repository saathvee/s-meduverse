import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Arjun Patel',
      exam: 'JEE Advanced 2024',
      rank: 'AIR 45',
      image: 'https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'AcademyPro helped me crack JEE Advanced with their excellent teaching methodology and regular mock tests. The doubt clearing sessions were incredibly helpful.',
      testimonial: 'S&M EDUVERSE helped me crack JEE Advanced with their excellent teaching methodology and regular mock tests. The doubt clearing sessions were incredibly helpful.',
      rating: 5
    },
    {
      name: 'Priya Singh',
      exam: 'NEET 2024',
      rank: 'AIR 123',
      image: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'The biology and chemistry courses were comprehensive and well-structured. I could not have achieved this rank without AcademyPro\'s guidance.',
      testimonial: 'The biology and chemistry courses were comprehensive and well-structured. I could not have achieved this rank without S&M EDUVERSE\'s guidance.',
      rating: 5
    },
    {
      name: 'Rajesh Kumar',
      exam: 'UPSC CSE 2023',
      rank: 'AIR 89',
      image: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'The current affairs updates and comprehensive study material helped me stay ahead. The mock interviews were particularly valuable for my preparation.',
      rating: 5
    },
    {
      name: 'Sneha Gupta',
      exam: 'CAT 2024',
      rank: '99.8 Percentile',
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'AcademyPro\'s quantitative and verbal courses were game-changers. The personalized attention and regular assessments kept me motivated throughout.',
      testimonial: 'S&M EDUVERSE\'s quantitative and verbal courses were game-changers. The personalized attention and regular assessments kept me motivated throughout.',
      rating: 5
    },
    {
      name: 'Vikram Sharma',
      exam: 'Banking PO 2024',
      rank: 'Selected in SBI',
      image: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'The reasoning and quantitative sections were made easy with AcademyPro\'s teaching methods. I got selected in my first attempt itself.',
      testimonial: 'The reasoning and quantitative sections were made easy with S&M EDUVERSE\'s teaching methods. I got selected in my first attempt itself.',
      rating: 5
    },
    {
      name: 'Anita Reddy',
      exam: 'State PSC 2024',
      rank: 'Rank 15',
      image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=400',
      testimonial: 'The state-specific preparation and regular current affairs updates were exactly what I needed. Thank you AcademyPro for making my dream come true.',
      testimonial: 'The state-specific preparation and regular current affairs updates were exactly what I needed. Thank you S&M EDUVERSE for making my dream come true.',
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            🎯 Our Vision & Student Success Stories
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            To create a learning ecosystem that nurtures excellence, builds confidence, and transforms every aspirant into a competent and ethical contributor to society.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 rounded-xl p-6 hover:shadow-md transition-shadow duration-300">
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{testimonial.name}</h3>
                  <p className="text-sm text-gray-600">{testimonial.exam}</p>
                  <p className="text-sm font-medium text-green-600">{testimonial.rank}</p>
                </div>
              </div>

              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>

              <div className="relative">
                <Quote className="h-8 w-8 text-blue-200 absolute -top-2 -left-2" />
                <p className="text-gray-700 italic leading-relaxed pl-6">
                  "{testimonial.testimonial}"
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;