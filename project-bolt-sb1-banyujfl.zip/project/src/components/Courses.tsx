import React from 'react';
import { ArrowRight, Clock, Users, Star } from 'lucide-react';

const Courses = () => {
  const courses = [
    {
      title: 'UPSC Preparation',
      description: 'Comprehensive coaching for CSE, EPFO, NDA, CDS with expert guidance and structured approach.',
      image: 'https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '18 months',
      students: 'New Course',
      rating: 4.9,
      subjects: ['General Studies', 'Optional', 'Current Affairs'],
    },
    {
      title: 'TNPSC Exams',
      description: 'Complete preparation for Group I, II, IV, VAO with Tamil Nadu specific content and guidance.',
      image: 'https://images.pexels.com/photos/4173239/pexels-photo-4173239.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '12 months',
      students: 'New Course',
      rating: 4.8,
      subjects: ['General Studies', 'Tamil', 'Current Affairs'],
    },
    {
      title: 'SSC Exams',
      description: 'Strategic preparation for CGL, CHSL, MTS with quantitative aptitude, reasoning, and English.',
      image: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '8 months',
      students: 'New Course',
      rating: 4.9,
      subjects: ['Quantitative', 'Reasoning', 'English'],
    },
    {
      title: 'Banking Exams',
      description: 'Complete preparation for IBPS, SBI PO/Clerk, RBI with banking awareness and aptitude.',
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '6 months',
      students: 'New Course',
      rating: 4.7,
      subjects: ['Banking Awareness', 'Quantitative', 'Reasoning'],
    },
    {
      title: 'UGC-NET',
      description: 'Focused preparation for Paper I & Social Work with research methodology and subject expertise.',
      image: 'https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '4 months',
      students: 'New Course',
      rating: 4.6,
      subjects: ['Research Methodology', 'Social Work', 'Teaching Aptitude'],
    },
    {
      title: 'Railways & Central Govt',
      description: 'Comprehensive preparation for railway exams and other central government job examinations.',
      image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=600',
      duration: '6 months',
      students: 'New Course',
      rating: 4.8,
      subjects: ['General Awareness', 'Quantitative', 'Reasoning'],
    }
  ];

  return (
    <section id="courses" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Popular Courses
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose from our comprehensive range of courses designed to help you succeed in your target exam
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow duration-300 overflow-hidden border border-gray-100">
              <div className="relative">
                <img 
                  src={course.image} 
                  alt={course.title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">{course.rating}</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{course.title}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{course.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {course.subjects.map((subject, idx) => (
                    <span key={idx} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                      {subject}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{course.students}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-300 flex items-center space-x-2 w-full justify-center">
                    <span>Enroll Now</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Courses;