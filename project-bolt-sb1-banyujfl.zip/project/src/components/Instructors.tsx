import React from 'react';
import { Award, BookOpen, Users } from 'lucide-react';

const Instructors = () => {
  const instructors = [
    {
      name: 'Saathvee',
      specialization: 'UPSC & TNPSC Expert',
      experience: 'Expert Faculty',
      image: 'https://images.pexels.com/photos/3862130/pexels-photo-3862130.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Dedicated to providing comprehensive guidance for competitive exam preparation with focus on concept clarity and practical application.',
      expertise: ['UPSC Preparation', 'TNPSC Coaching', 'Current Affairs', 'General Studies']
    },
    {
      name: 'Madheswar',
      specialization: 'Banking & SSC Specialist',
      experience: 'Expert Faculty',
      image: 'https://images.pexels.com/photos/5212317/pexels-photo-5212317.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Specialized in quantitative aptitude, reasoning, and banking awareness with proven track record in student success.',
      expertise: ['Banking Exams', 'SSC Preparation', 'Quantitative Aptitude', 'Reasoning']
    }
  ];

  return (
    <section id="instructors" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Meet Our Expert Faculty
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Learn from experienced educators who are passionate about your success
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {instructors.map((instructor, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <img 
                    src={instructor.image} 
                    alt={instructor.name}
                    className="w-20 h-20 rounded-full object-cover mr-6"
                  />
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-1">{instructor.name}</h3>
                    <p className="text-blue-600 font-semibold mb-1">{instructor.specialization}</p>
                    <p className="text-gray-600 text-sm">{instructor.experience}</p>
                  </div>
                </div>

                <p className="text-gray-700 mb-6 leading-relaxed">{instructor.description}</p>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 flex items-center">
                    <BookOpen className="h-5 w-5 text-blue-600 mr-2" />
                    Areas of Expertise
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {instructor.expertise.map((skill, idx) => (
                      <span key={idx} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      <span>Expert Faculty</span>
                    </div>
                    <div className="flex items-center">
                      <Award className="h-4 w-4 mr-1" />
                      <span>Proven Results</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Instructors;